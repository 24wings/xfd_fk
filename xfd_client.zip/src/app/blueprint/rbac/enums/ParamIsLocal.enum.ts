export enum ParamsIsLocalEnum {
    /**全局 */
    Gloab = "gloab",
    /**本都 */
    Local = "local"
}
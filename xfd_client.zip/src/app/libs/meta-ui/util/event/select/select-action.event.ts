import { MetaCom } from "../../meta/MetaCom";

export class SelectActionEvent {
    metaCom: MetaCom;
    data: any;
}

export class Decimal extends Number {

}

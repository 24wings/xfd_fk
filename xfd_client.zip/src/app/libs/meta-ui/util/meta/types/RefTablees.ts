export class RefTablees extends Array {

}
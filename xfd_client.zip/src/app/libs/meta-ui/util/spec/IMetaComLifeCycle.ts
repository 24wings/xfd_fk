import { IBeforeDelete } from "./basic/lifecycle/IBeforeDelete";

export interface IMetaComLifecycle extends IAfterCreateSuceess, IBeforeDelete {

}
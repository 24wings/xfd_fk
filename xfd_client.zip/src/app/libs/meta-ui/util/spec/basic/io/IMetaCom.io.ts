import { MetaCom } from "../../../meta/MetaCom";

export class IMetaComIO {
    metaObject: MetaCom;
}
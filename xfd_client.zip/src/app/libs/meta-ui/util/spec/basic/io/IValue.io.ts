export interface IValueIO<T> {
    __value__: T;
    value: T;
}
interface IAfterCreateSuceess {
    afterCreateSuccess: (data: any) => any;
}
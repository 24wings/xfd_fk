# 组件规范

- [x] BasicComSpec 基础组件规范
- [ ] RefComSPec  引用组件规范
- [ ] StringComSpec 
# String组件规范
transform
* read
* write
* formatter
* parserer
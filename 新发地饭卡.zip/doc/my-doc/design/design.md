Account 
name
accountId:number
balance
createTime
fronzenMoney
status
userType :'market','member','market'
moneyType:'online'


/***/
AccountRecvpay
accountId
accountName
toAccountId
toAccountName
flag:
money,
createTime
orderId

x

public class Msg {

    public int msgId;
   title:"'
    public String content;

    public Date sendTime = new Date();
  
    public contentType="transition"
    public String sendType = "msg";
    isJpush:boolean
    isSms:boolean
    public String addtion;
    public String bizId;
    public String phone;
    public Integer mktId;
    status:'checked' |'unallchecked'|
   sendToCustomerId
}

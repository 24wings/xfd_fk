### 目录

[swagger-ui接口与实体规范](swagger-ui.html)


**设计与规范**
* [代码最佳实践](最佳实践.html)
* [设计与架构](map.html)



* ng2技术




**技术文档:**
* [angular2 中文文档](https://angular.cn/)
* [angular2 英文文档](https://angular.io/)
* [typescript 中文文档](https://www.tslang.cn/)
* [typescript 英文文档](https://www.typescriptlang.org/)
* [cordova config.xml配置 官方文档](https://cordova.apache.org/docs/en/latest/config_ref/index.html)
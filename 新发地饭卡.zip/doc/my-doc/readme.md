# app端移动智能交易系统

**[当前开发进度]**

**backend**
* 第三方实名认证接口(阿里云聚合数据,实名认证)   羊
* [修改手机](./app/modify_phone.html) 鱼
* [我的团队](./app/3.1.my_team.html)  鱼
* [消息管理](./app/4.msg_manage.html)  杨
* [待处理消息](./app/4.msg_manage.html) 杨
* [商品管理](./app/5.product_manage.html)  杨  
* [交易开单](./app/6.product_order.html) 鱼
* [交易费率]('./app/7.txn_rate.html) 鱼
* [钱包](./app/8.money_pack.html)  鱼
* [我的交易](./app/9.my_biz.html) 鱼

# client
* [修改手机](./app/modify_phone.html) 鱼
* [我的团队](./app/3.1.my_team.html) 张 
* [消息管理](./app/4.msg_manage.html) 严
* [待处理消息](./app/4.msg_manage.html) 严
* [商品管理](./app/5.product_manage.html) 张
* [交易开单](./app/6.product_order.html) 严
* [交易费率](./app/7.txn_rate.html)  张
* [钱包](./app/money_pack.html) 张
* [我的交易](./app/9.my_biz.html) 张

# 开发文档目录

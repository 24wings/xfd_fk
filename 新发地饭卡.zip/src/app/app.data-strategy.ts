import { IndexedDbStrategyService } from "@core/service/data-strategy/IndexedDbStrategy.service";
import { OnlineStrategyService } from "@core/service/data-strategy/OnlineStrategy.service";

export const DataStrategy = OnlineStrategyService;
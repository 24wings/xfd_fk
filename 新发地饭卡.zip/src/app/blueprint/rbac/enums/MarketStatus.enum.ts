export enum MarketStatusEnum {
    Active = "active",
    Disabled = "disabled",
    /** 冻结*/
    Frozen = "frozen"//冻结
}

import { MetaCom } from "../../meta/MetaCom";

export class EditActionEvent {
    metaCom: MetaCom;

}
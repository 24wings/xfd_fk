export enum ValidStatusEnum {
    success = 'success',
    warning = 'warning',
    error = 'error',
    validating = 'validating'
}
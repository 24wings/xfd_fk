export class Picture extends String {

}
export class RefTable {

}
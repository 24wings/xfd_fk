export class Timestamp extends Date {

}
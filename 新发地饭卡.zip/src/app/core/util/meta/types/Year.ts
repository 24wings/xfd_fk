export class Year extends Date {

}
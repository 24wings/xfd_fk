export interface Paging<T> {
    rows: T[];
    count: number;
}
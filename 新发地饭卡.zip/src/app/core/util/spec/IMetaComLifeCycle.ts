export interface IMetaComLifecycle extends IAfterCreateSuceess {

}
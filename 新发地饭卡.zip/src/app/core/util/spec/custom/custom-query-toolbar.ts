import { EventEmitter } from "@angular/core";
import { MetaCom } from "../../meta/MetaCom";

export class CustomQueryToolbarComSpec {
    metaCom: MetaCom;
    rowsChange = new EventEmitter();
    async query() {

    }
}
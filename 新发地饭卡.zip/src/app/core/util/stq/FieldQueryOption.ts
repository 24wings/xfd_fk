interface FieldQueryOption {
    field: string;
    value: any;
    compare: string;
    joinStr?: string;
  }
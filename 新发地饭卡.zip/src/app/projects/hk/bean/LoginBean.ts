export class LoginBean {
    userName: string;
    password: string;
}
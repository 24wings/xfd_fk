export class AirCompany {
    /**航司Id*/
    id: number;
    /**航司代码*/
    code: string;
    /**航司全名*/
    name: string;
    /**航司简称*/
    shortNam: string;

}

export class Airport {
    /**机场Id*/
    id?: number;
    /**代码*/
    code?: string;
    /**名称*/
    name?: string;
    cityCode?: string | any;

}


export class City {
    /**城市Id*/
    id?: number;
    /**城市代码*/
    code?: string;
    /**城市名*/
    name?: string;
    /**国家代码*/
    countryCode?: string;
}

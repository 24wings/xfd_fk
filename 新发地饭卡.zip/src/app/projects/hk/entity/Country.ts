export class Country {
    /**国家Id*/
    id: number;
    /**国家代码*/
    code: string;
    /**国家名*/
    name: string;
}

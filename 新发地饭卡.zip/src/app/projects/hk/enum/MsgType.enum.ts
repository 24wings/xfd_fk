
export enum MsgTypeEnum {
    Notify = 1,
    Message,
    Task
    //  ACTOR_CHANGE, CUST_INVITE, REPAY_APPLY, REPAY_CONFIRM, TOBE_PAY
}

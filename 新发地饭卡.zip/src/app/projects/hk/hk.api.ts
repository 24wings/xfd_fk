export let hkApi = {
    login: '/hk/user/login'
} 
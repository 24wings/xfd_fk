import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { StringComSpec } from '@core/util/spec/field/string.comspec';
import { ValidService } from '@core/service/validate.service';

@Component({
  selector: 'ic-card-reader',
  templateUrl: './ic-card-reader.component.html',
  styleUrls: ['./ic-card-reader.component.css']
})
export class IcCardReaderComponent extends StringComSpec implements OnInit {
  constructor(private valid: ValidService, private httpClient: HttpClient) { super(valid) }
  ngOnInit() {
  }
  async  blur() {
    this.value = await this.getCardNo();
  }
  async getCardNo(): Promise<any> {
    let baseUrl = "http://localhost:8000/GetICNO";
    return new Promise(resolve => this.httpClient.get(baseUrl).subscribe(rtn => {
      if (rtn['ICNO']) {
        resolve(rtn['ICNO'])
      }
    }))
  }
}

import { Component, OnInit, EventEmitter, Input, Output } from '@angular/core';
import { NzTreeNode, NzTreeNodeOptions } from 'ng-zorro-antd';
import { ValidService } from '@core/service/validate.service';
import { RefTableComSpec } from '@core/util/spec/field/ref-table.comspec';
import { MetaCom } from '@core/util/meta/MetaCom';
import { ModeEnum } from '@core/util/meta/Mode.enum';
import { Field } from '@core/util/meta/Field';
import { ValidStatusEnum } from '@core/util/meta/ValidStatus.enum';
import { listToNzTreeNode } from '@core/util/struct/listToTree';

@Component({
  selector: 'field-ref-tree-many-zorro',
  templateUrl: './field-ref-tree-many-zorro.component.html',
  styleUrls: ['./field-ref-tree-many-zorro.component.css']
})
export class FieldRefTreeManyZorroComponent extends RefTableComSpec implements OnInit {
  @Input() metaCom: MetaCom;
  @Input() mode: ModeEnum;
  @Input() field: Field;

  __dataSet__ = []
  @Input() set dataSet(dataSet: any[]) {
    this.__dataSet__ = dataSet;
    if (this.__dataSet__)
      if (this.__dataSet__.length > 0)
        this.parseCheckedTree();
    console.log('dataset,', dataSet)
  }
  get dataSet() {
    return this.__dataSet__;
  }

  @Input() set value(rows: any) {
    if (typeof rows == 'string') {
      this.__value__ = rows.split(',');
    } else {
      this.__value__ = rows;
    }
    let result = this.validService.valid(rows, this.field.valid);
    if (result.ok) {
      this.validStatus = ValidStatusEnum.success;
      this.errMsg = "";
    } else {
      this.validStatus = ValidStatusEnum.error;
      this.errMsg = result.msg;
    }
    this.parseCheckedTree()

  }
  get value() {
    return this.__value__;
  }
  nodes: NzTreeNode[] = [];
  page: number = 1;
  total: number = 10;
  constructor(public validService: ValidService) { super(validService) }

  parseCheckedTree() {
    if (!this.value) this.value = []
    this.nodes = listToNzTreeNode(this.__dataSet__.map(item => {
      let data = Object.assign(new this.metaCom.view.treeClass(), item);
      data.checked = !!this.value.find(id => id == data.getId());
      data.disabled = this.mode == ModeEnum.Show;
      return data;
    }).filter(item => item.checked)
    );


  }
  ngOnInit() {
    console.log(this.value)
    this.query()
  }

  select($event: { node: NzTreeNode }) {
    console.log($event);
    this.valueChange.emit(parseInt($event.node.key));

  }
  check($event: { node: NzTreeNode }) {
    // this.checked.emit($event.node.key);
  }
  async  query() {
    this.onQuery.emit({ metaCom: this.metaCom, keyword: '' })
  }

  checkMany() {
    let ids: string[] = [];
    this.nodes.forEach(node => ids.push(...this.getCheckedMenuIds(node)));
    this.value = ids;
    this.valueChange.emit(ids);
  }
  getCheckedMenuIds(menu: NzTreeNode | NzTreeNodeOptions): string[] {
    let checkedMenuIds: string[] = [];
    if ((menu as NzTreeNode).isChecked || (menu as NzTreeNode).isHalfChecked || (menu as NzTreeNodeOptions).checked) checkedMenuIds.push(menu.key);
    if (menu.children.length > 0) {
      for (let child of menu.children) {
        checkedMenuIds.push(...this.getCheckedMenuIds(child));
      }
    }
    return checkedMenuIds;
  }



}

# 建议统一在 `widgets` 目录下自定义小部件

> 注：@delon/form 本身提供 nz-zorro-antd 数据录入组件的全部实现，以及若干第三方组件的代码，可从[widgets-third](https://github.com/ng-alain/delon/tree/master/packages/form/widgets-third)中获取并放置 `widgets` 目录下注册即可。
